Business & avatar
=================

Designer: Hopnguyen Mr (https://www.iconfinder.com/Mr.hopnguyen)
License: Free for commercial use
